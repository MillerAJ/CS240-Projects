CS240 Data Structures
Spring Semester 2016
Lab1 READMEFILE

Due Date: 2/10/16
Submission Date: 2/9/16
Author(s): Alex Miller
email(s): amille31@binghamton.edu

PURPOSE:
	Create a simple program and class to print text to screen. Learn C++ basics.

PERCENT COMPLETE:
	100%
	
PARTS THAT ARE NOT COMPLETE:
	N/A

BUGS:
	N/A

FILES:
	lab1.cpp, Hello.cpp, Hello.h, makefile, readme.txt

SAMPLE OUTPUT:
	"Hello World"
	"C++ Data Structures!"
	"Hello from the Hello Class!"

TO RUN:
	make
	./lab1

EXTRA CREDIT:
	N/A

BIBLIOGRAPHY:
	N/A

MISCELLANEOUS:
	N/A



	

