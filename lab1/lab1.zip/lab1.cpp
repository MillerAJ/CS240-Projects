#include "Hello.h"
#include <iostream>

int main(){
std::cout << "Hello World!" << std::endl;
std::cout << "C++ Data Structures!" << std::endl;
Hello hello;
hello.printHello();

return 0;

}
