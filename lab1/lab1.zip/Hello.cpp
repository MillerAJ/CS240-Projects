#include "Hello.h"
#include <iostream>

void Hello::printHello(){
std::cout << "Hello from the Hello Class!" << std::endl;

}

