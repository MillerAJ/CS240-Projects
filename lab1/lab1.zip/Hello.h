//#include <guards>
#ifndef HELLO_H
#define HELLO_H
#include <iostream>

	class Hello{
		public:
			void printHello(void);
	};

#endif
