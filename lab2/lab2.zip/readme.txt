CS240 Data Structures
Spring Semester 2016
Lab2 READMEFILE

Due Date: 2/17/16
Submission Date: 2/17/16
Author(s): Alex Miller
email(s): amille31@binghamton.edu

PURPOSE:
	Create an User class, and have a main function which allows for manipulation of that class.

PERCENT COMPLETE:
	100%
	
PARTS THAT ARE NOT COMPLETE:
	N/A

BUGS:
	N/A

FILES:
	lab2.cpp, User.cpp, User.h, makefile, readme.txt

SAMPLE OUTPUT:
	"Please enter a command (Create, Update, View, Favorites, or Quit):"

TO RUN:
	make lab2
	./lab2

EXTRA CREDIT:
	N/A

BIBLIOGRAPHY:
	N/A

MISCELLANEOUS:
	N/A
