CS240 Data Structures
Spring Semester 2016
Lab3 READMEFILE

Due Date: 2/24/16
Submission Date: 2/24/16
Author(s): Alex Miller
email(s): amille31@binghamton.edu

PURPOSE:
	Add a username and password to the User class. Create a MovieChart class to encapsualte users.
	Add login and logout functions.

PERCENT COMPLETE:
	100%
	
PARTS THAT ARE NOT COMPLETE:
	N/A

BUGS:
	N/A

FILES:
	lab3.cpp, User.cpp, User.h, MovieChart.h, MovieChart.cpp, makefile, readme.txt

SAMPLE OUTPUT:
	"Please enter a command (Create, Update, View, Login, Logout, or Quit):"

TO RUN:
	make lab3
	./lab3

EXTRA CREDIT:
	N/A

BIBLIOGRAPHY:
	N/A

MISCELLANEOUS:
	N/A
