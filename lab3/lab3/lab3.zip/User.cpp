#include "User.h"
#include <iostream>
using namespace std;

User::User(){
	this->movies = new string[5];
}

User::User(string fname, string lname, int age, string username, string password){
	this->firstName = fname;
	this->lastName = lname;
	this->myAge = age;
	this->Username = username;
	this->Password = password;
	this->movies = new string[5];
}


string* User::movieList(){
	return this-> movies;
}

string User::getFavMovie(int num){
	return movies[num];
}

bool User::authenticate(string password){
	if (password == this->getPassword()){
		return true;
	} else {
		return false;
	}
}

string User::getFirstName(){
	return this->firstName;
}

string User::getLastName(){
	return this->lastName;
}


int User::getAge(){
	return this->myAge;
}

string User::getUsername(){
	return this->Username;
}

string User::getPassword(){
	return this->Password;
}

void User::setFavMovie(int i, string title){
	this->movies[i] = title;	
}

void User::setFirstName(string name){
	this->firstName = name;
}

void User::setLastName(string name){
	this->lastName = name;
}

void User::setAge(int age){
	this->myAge =age;
}

void User::setPassword(string pass){
	this->Password = pass;
}

void User::setUsername(string name){
	this->Username = name;
}

