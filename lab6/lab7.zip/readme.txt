CS240 Data Structures
Spring Semester 2016
Lab7 READMEFILE

Due Date: 4/6/16
Submission Date: 4/6/16
Author(s): Alex Miller
email(s): amille31@binghamton.edu

PURPOSE:
	Binary Serach Tree traverisal and removal

PERCENT COMPLETE:
	???
	
PARTS THAT ARE NOT COMPLETE:
	pretty much everything
	the vector list part works

BUGS:
	tried to do deletion by removing every subnode under a node, and then reinserting all nodes except the one 
	which was intended to be removed. doesnt work for some reason, ends up with seg faults	

FILES:
	lab7.cpp, BSTree.h, BSTree.cpp, makefile, readme.txt

SAMPLE OUTPUT:
	

TO RUN:
	make lab7
	./lab7

EXTRA CREDIT:
	N/A

BIBLIOGRAPHY:
	N/A

MISCELLANEOUS:
	N/A
