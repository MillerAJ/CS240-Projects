#include "BSTree.h"
#include<cstddef>
#include<iostream>

BSTree::BSTree(){
root= NULL;
}

BSTree::~BSTree(){
	delete root;
}

bool BSTree::empty(){
	if(root==NULL){
		return true;
	} else {
		return false;	
	}
}

bool BSTree::find(int val){
	if(root != NULL && root->value == val){
		return true;
	} else if (root!=NULL && root->value != val){
		Node* temp = root;
		while (temp != NULL){
			if(temp->value > val){
				temp = temp->left;
			} else if (temp->value < val){	
				temp =temp->right;	
			} else if (temp->value == val){
				//delete temp;
				return true;
			}
		}
		return false;	
	}
}
/*
bool BSTree::insertNode(Node* temp,int val){
		while (temp != 0){
			if(temp->value > val){
				temp = temp->left;
			} else if (temp->value < val){	
				temp =temp->right;	
			}
		} temp = new Node(val);
		return true;	
	}
*/



bool BSTree::insertNode(Node* current_node, Node* insert_node){	
	if(insert_node->value > current_node->value){
		if(current_node->right != NULL){
			insertNode(current_node->right, insert_node);
		} else {	
			current_node->right = insert_node;
			return true;
		}
	} else if(insert_node->value < current_node->value) {
		if(current_node->left != NULL){
			insertNode(current_node->left, insert_node);
		} else {
			current_node->left = insert_node;
			return true;
		}
	} else {
		return false;
	}
}

bool BSTree::insert(int val){
	bool success = false;
	Node* newNode = new Node(val);
		if(root==NULL){
			root= newNode;
			success = true;
		} else {
			success = insertNode(root,newNode);
		//	success = insertNode(root, val);
		}	
	return success;
}




