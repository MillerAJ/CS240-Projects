CS240 Data Structures
Spring Semester 2016
lab8 READMEFILE

Due Date: 4/27/16
Submission Date: 4/27/16
Author(s): Alex Miller
email(s): amille31@binghamton.edu

PURPOSE:
	Practice using various sorts

PERCENT COMPLETE:
	100%
	
PARTS THAT ARE NOT COMPLETE:
	N/A

BUGS:
	N/A

FILES:
	Sort.cpp, Sort.h, makefile, readme.txt

SAMPLE OUTPUT:
	N/A

TO RUN:
	make lab8
	./lab8

EXTRA CREDIT:
	incomplete

BIBLIOGRAPHY:
	N/A

MISCELLANEOUS:
	N/A


