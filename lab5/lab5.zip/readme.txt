CS240 Data Structures
Spring Semester 2016
Lab5 READMEFILE

Due Date: 3/16/16
Submission Date: 3/15/16
Author(s): Alex Miller
email(s): amille31@binghamton.edu

PURPOSE:
	Use deque data structure to simulate a deck of cards

PERCENT COMPLETE:
	100%
	
PARTS THAT ARE NOT COMPLETE:
	N/A

BUGS:
	N/A

FILES:
	lab5.cpp, Deck.h, Deck.cpp, Card.h, Card.cpp, makefile, readme.txt

SAMPLE OUTPUT:
	"Heart 1"
	"Spade 1"
	"Diamond 1" 
	"Club 1"
	... etc ...

TO RUN:
	make lab5
	./lab5

EXTRA CREDIT:
	N/A

BIBLIOGRAPHY:
	N/A

MISCELLANEOUS:
	N/A




